"use client";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Image from "next/image";
const AbroadUniveritySlider = () => {
  var settings = {
    dots: false,
    infinite: true,
    speed: 1000,
    slidesToShow: 4,
    slidesToScroll: 1,
    responsive: [
      {
        breakpoint: 1200,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
        },
      },

      {
        breakpoint: 800,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 450,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
  };
  return (
    <div className="success-stories">
      <Slider
        autoplay
        {...settings}
        className="items-center justify-center grid gap-6"
      >
        {abroadUniArray?.map((item, index) => {
          return (
            <div key={index} className="shadow-xl rounded-xl">
              <div>
                <Image src={item?.imageUrl} alt="image" width={336} height={336} />
              </div>
              <div className="text-center p-4 text-[#0288d1]">
                <p className="font-semibold">{item?.caption}</p>
                <span>{item?.country}</span>
              </div>
            </div>
          );
        })}
      </Slider>
    </div>
  );
};
export default AbroadUniveritySlider;
const abroadUniArray = [
  {
    imageUrl: "/abroad-slider/01.jpg",
    caption: "University of Arizona",
    country: "(United States of America)",
  },
  {
    imageUrl: "/abroad-slider/02.jpg",
    caption: "Walsh College",
    country: "(United States of America)",
  },
  {
    imageUrl: "/abroad-slider/03.jpg",
    caption: "Oklahoma City University",
    country: "(United States of America)",
  },
  {
    imageUrl: "/abroad-slider/04.png",
    caption: "FOM University",
    country: "(Germany)",
  },
  {
    imageUrl: "/abroad-slider/05.png",
    caption: "Eller College of Management",
    country: "(United States of America)",
  },
];
