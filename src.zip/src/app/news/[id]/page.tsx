import HeaderLayout from "@/app/components/headerLayout/HeaderLayout";
import Blog from "@/app/models/blogModels";
import React from "react";

const News = () => {
  return (
    <>
      <HeaderLayout>
        <h2>News blogs</h2>
      </HeaderLayout>
    </>
  );
};

export default News;
