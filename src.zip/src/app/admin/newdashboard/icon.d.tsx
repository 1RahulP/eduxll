import * as React from "react";

interface SVGICONPROPS extends React.SVGProps<SVGSVGElement> {
  iconColor?: string;
  iconSize?: number;
  blankStar?: any;
  color?: any;
}
