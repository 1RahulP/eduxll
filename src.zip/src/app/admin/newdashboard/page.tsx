"use client";
import Image from "next/image";
import React, { useState } from "react";
import SideBarLayout from "./ui/sidebarlayout/page";

const NewDashboard = () => {
  return (
    <>
      <SideBarLayout>
        <div>jhkjkh</div>
      </SideBarLayout>
    </>
  );
};
export default NewDashboard;
