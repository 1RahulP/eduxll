import React from 'react'

const Loader = () => {
  return (
    <div className="loadingSpinnerContainer">
            <div className="loadingSpinner"></div>
    </div>
  )
}

export default Loader