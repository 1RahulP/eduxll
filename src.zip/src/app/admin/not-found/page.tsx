const NotFound = () =>{
    return(
        <h1 className="p-4">Not found</h1>
    )
}
export default NotFound