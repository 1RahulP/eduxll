import CreateCoursesform from "@/app/components/admin/courses/CreateCoursesform";


const CreateCourse = () => {
  return (
    <div className="grid gap-4">
      <CreateCoursesform/>
    </div>
  );
};
export default CreateCourse;
